//
// Created by mfbut on 5/2/2019.
//

#ifndef MATRIX_MATRIXTYPEDEFS_H
#define MATRIX_MATRIXTYPEDEFS_H
namespace Matrix{
  using ValueType = double;
  using SizeType = int;
}

#endif //MATRIX_MATRIXTYPEDEFS_H
